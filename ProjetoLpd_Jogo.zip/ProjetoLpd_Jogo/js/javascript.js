document.getElementById("botao2").addEventListener("click", function() {
    window.location.href = "comojogar.html";
});
document.getElementById("botao1").addEventListener("click", function() {
    window.location.href = "encontreospares.html";
});